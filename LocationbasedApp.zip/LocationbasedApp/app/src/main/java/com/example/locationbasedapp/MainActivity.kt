package com.example.locationbasedapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.locationbasedapp.ui.theme.LocationbasedAppTheme
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import com.google.android.gms.location.LocationServices


class MainActivity : ComponentActivity() {
    private val nominatimApi: NominatimApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://nominatim.openstreetmap.org/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(NominatimApi::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // OpenStreetMap-Konfiguration initialisieren
        Configuration.getInstance().load(this, this.getPreferences(MODE_PRIVATE))

        setContent {
            LocationbasedAppTheme {
                ShowNearbyCinemas()
            }
        }
    }

    @Composable
    fun ShowNearbyCinemas() {
        var currentLocation by remember { mutableStateOf<GeoPoint?>(null) }
        var cinemaLocations by remember { mutableStateOf(listOf<GeoPoint>()) }

        // Berechtigungen anfordern
        val permissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                getCurrentLocation { location ->
                    currentLocation = GeoPoint(location.latitude, location.longitude)
                    fetchNearbyCinemas(currentLocation!!) { cinemas ->
                        cinemaLocations = cinemas
                    }
                }
            } else {
                Toast.makeText(this@MainActivity, "Standortberechtigung benötigt", Toast.LENGTH_SHORT).show()
            }
        }

        LaunchedEffect(Unit) {
            if (ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            } else {
                getCurrentLocation { location ->
                    currentLocation = GeoPoint(location.latitude, location.longitude)
                    fetchNearbyCinemas(currentLocation!!) { cinemas ->
                        cinemaLocations = cinemas
                    }
                }
            }
        }

        // OpenStreetMap anzeigen
        AndroidView(factory = { context ->
            MapView(context).apply {
                setTileSource(TileSourceFactory.MAPNIK)
                controller.setZoom(15.0)

                // Aktuellen Standort setzen, wenn verfügbar
                currentLocation?.let {
                    controller.setCenter(it)
                    // Marker für den aktuellen Standort
                    val marker = Marker(this)
                    marker.position = it
                    marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    marker.title = "Mein Standort"
                    overlays.add(marker)
                }

                // Marker für Kinos setzen
                cinemaLocations.forEach { location ->
                    val marker = Marker(this)
                    marker.position = location
                    marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    marker.title = "Kino"
                    overlays.add(marker)
                }
            }
        }, modifier = Modifier.fillMaxSize())
    }

    private fun getCurrentLocation(onLocationReceived: (android.location.Location) -> Unit) {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                location?.let {
                    onLocationReceived(it)
                }
            }
        }
    }

    private fun fetchNearbyCinemas(currentLocation: GeoPoint, onCinemasFetched: (List<GeoPoint>) -> Unit) {
        // Verwende Nominatim-API, um Kinos in der Nähe zu suchen
        nominatimApi.searchCinemas(
            "${currentLocation.latitude},${currentLocation.longitude}",
            10000 // Radius in Metern (10 km)
        ).enqueue(object : retrofit2.Callback<List<NominatimPlace>> {
            override fun onResponse(
                call: retrofit2.Call<List<NominatimPlace>>,
                response: retrofit2.Response<List<NominatimPlace>>
            ) {
                if (response.isSuccessful) {
                    val cinemas = response.body()?.map {
                        GeoPoint(it.lat.toDouble(), it.lon.toDouble())
                    } ?: listOf()
                    onCinemasFetched(cinemas)
                }
            }

            override fun onFailure(call: retrofit2.Call<List<NominatimPlace>>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Fehler bei der Kinosuche", Toast.LENGTH_SHORT).show()
            }
        })
    }
}

// Retrofit API-Schnittstelle für Nominatim
interface NominatimApi {
    @GET("search?format=json&amenity=cinema")
    fun searchCinemas(
        @Query("q") location: String,
        @Query("radius") radius: Int
    ): retrofit2.Call<List<NominatimPlace>>
}

data class NominatimPlace(val lat: String, val lon: String)

